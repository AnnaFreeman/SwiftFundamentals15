//
//  ViewController.swift
//  Light
//
//  Created by fall2026 on 11/11/26.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var lightButton: UIButton!
    var lightOn = true
    fileprivate func updateUI() {
        
        view.backgroundColor  = lightOn ? .white:
            .black
    }
          //  lightButton.setTitle("Off", for: .normal)
  //      } else
   //     {
    //        view.backgroundColor = .black
          //  lightButton.setTitle("On", for: .normal)
  //      }
 //   }
    
    @IBAction func buttonPressed(_ sender: Any) {
        lightOn.toggle()
        updateUI()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }


}

