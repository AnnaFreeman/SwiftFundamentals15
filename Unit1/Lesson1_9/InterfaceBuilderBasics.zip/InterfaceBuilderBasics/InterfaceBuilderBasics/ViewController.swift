//
//  ViewController.swift
//  InterfaceBuilderBasics
//
//  Created by fall2026 on 11/9/26.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func changeTitle(_ sender: Any) {
    }
    @IBOutlet weak var mainLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        mainLabel.text = "This app rocks!"
    }
}

